#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Somme les lignes 'RESULT a d b' de jass_vs_jass_arch.py et donne score, Elo,
IC95 (approximation normale sur le trinôme). A = candidat, B = champion.

usage: sum_results.py FILE [FILE ...]   -> markdown sur stdout
"""
import math
import sys


def elo(p):
    p = min(max(p, 1e-6), 1 - 1e-6)
    return -400 * math.log10(1 / p - 1)


def main(paths):
    a = d = b = 0
    for p in paths:
        last = None
        for line in open(p):
            if line.startswith("RESULT "):
                last = line.split()
        if last is None:
            print(f"<!-- {p}: aucune ligne RESULT -->")
            continue
        a += int(last[1]); d += int(last[2]); b += int(last[3])
    n = a + d + b
    if n == 0:
        print("Aucune partie terminée.")
        return 1
    s = (a + 0.5 * d) / n
    var = (a * (1 - s) ** 2 + d * (0.5 - s) ** 2 + b * (0 - s) ** 2) / n
    se = math.sqrt(var / n)
    lo, hi = s - 1.96 * se, s + 1.96 * se
    print(f"| parties | cand. gagne | nulles | champion gagne | score | Elo | IC95 Elo |")
    print(f"|---:|---:|---:|---:|---:|---:|---|")
    print(f"| {n} | {a} | {d} | {b} | {s:.4f} | {elo(s):+.1f} | [{elo(lo):+.1f} ; {elo(hi):+.1f}] |")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
