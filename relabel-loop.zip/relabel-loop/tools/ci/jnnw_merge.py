#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Concatène des fichiers JNNW (header 'JNNW' + uint32 count, records de 38 B).

usage: jnnw_merge.py OUT IN [IN ...]   (l'ordre des entrées est conservé)
"""
import os
import struct
import sys

REC = 38


def main(argv):
    if len(argv) < 3:
        sys.exit(__doc__)
    out_path, inputs = argv[1], argv[2:]
    total = 0
    with open(out_path, "wb") as out:
        out.write(b"JNNW" + struct.pack("<I", 0))
        for p in inputs:
            with open(p, "rb") as f:
                head = f.read(8)
                if len(head) != 8 or head[:4] != b"JNNW":
                    sys.exit(f"{p}: bad magic")
                count = struct.unpack_from("<I", head, 4)[0]
                if os.path.getsize(p) != 8 + count * REC:
                    sys.exit(f"{p}: size != header-implied {8 + count * REC}")
                while chunk := f.read(1 << 24):
                    out.write(chunk)
            total += count
            print(f"  {p}: +{count:,} -> {total:,}")
        if total >= 2 ** 32:
            sys.exit("too many records for a uint32 header")
        out.seek(4)
        out.write(struct.pack("<I", total))
    print(f"wrote {out_path}: {total:,} records")


if __name__ == "__main__":
    main(sys.argv)
