#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Cible externe black-POV pour train_stream.py --target external.

    y = lam * WDL + (1 - lam) * sigmoid(score / s)

WDL et score sont lus dans les records JNNW (POV side-to-move, convertis en
POV noir comme train_stream). L'échelle s est ajustée sur les données : c'est
le s qui maximise la vraisemblance du WDL observé sachant le score profond
(régression logistique à un paramètre, sans biais). Ainsi le score est exprimé
dans la même échelle de probabilité que le résultat de partie.

usage: blend_targets.py DATA.jnnw OUT.npy --lam 0.3 [--report R.json]
"""
import argparse
import json

import numpy as np

DT = np.dtype([('wm', '<u8'), ('wk', '<u8'), ('bm', '<u8'), ('bk', '<u8'),
               ('stm', 'u1'), ('score', '<i4'), ('wdl', 'i1')])


def fit_scale(score, y, max_abs=20000):
    keep = (np.abs(score) < max_abs) & (y != 0.5)   # nulles et mats exclus du fit
    s, t = score[keep], y[keep]
    if len(s) < 1000:
        raise SystemExit(f"trop peu de parties décisives pour caler l'échelle ({len(s)})")
    grid = np.geomspace(20, 5000, 200)
    ll = []
    for c in grid:
        p = np.clip(1 / (1 + np.exp(-s / c)), 1e-7, 1 - 1e-7)
        ll.append(np.mean(t * np.log(p) + (1 - t) * np.log(1 - p)))
    return float(grid[int(np.argmax(ll))]), float(max(ll)), int(len(s))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data")
    ap.add_argument("out")
    ap.add_argument("--lam", type=float, required=True, help="poids du WDL dans [0,1]")
    ap.add_argument("--report", default=None)
    a = ap.parse_args()
    if not 0.0 <= a.lam <= 1.0:
        raise SystemExit("--lam doit être dans [0,1]")
    raw = np.memmap(a.data, dtype='u1', mode='r')
    if bytes(raw[:4]) != b"JNNW":
        raise SystemExit("bad magic")
    n = int(np.frombuffer(bytes(raw[4:8]), '<u4')[0])
    rec = np.frombuffer(raw[8:8 + n * DT.itemsize], dtype=DT)
    black = rec['stm'] == 1
    wdl = rec['wdl'].astype(np.float64)
    score = rec['score'].astype(np.float64)
    y_wdl = (np.where(black, wdl, -wdl) + 1.0) * 0.5
    s_black = np.where(black, score, -score)
    if not np.any(score):
        raise SystemExit("tous les scores sont nuls (--wdl-zero-score ?) : pas de relabel à mélanger")
    scale, ll, n_fit = fit_scale(s_black, y_wdl)
    y_val = 1.0 / (1.0 + np.exp(-np.clip(s_black / scale, -60, 60)))
    y = (a.lam * y_wdl + (1.0 - a.lam) * y_val).astype(np.float32)
    np.save(a.out, y, allow_pickle=False)
    rep = {"records": n, "lam": a.lam, "fitted_scale": scale,
           "fit_loglik": ll, "fit_decisive_records": n_fit,
           "draw_rate": float(np.mean(y_wdl == 0.5)),
           "target_mean": float(y.mean()), "target_std": float(y.std())}
    print(json.dumps(rep, indent=2))
    if a.report:
        with open(a.report, "w") as f:
            json.dump(rep, f, indent=2)


if __name__ == "__main__":
    main()
